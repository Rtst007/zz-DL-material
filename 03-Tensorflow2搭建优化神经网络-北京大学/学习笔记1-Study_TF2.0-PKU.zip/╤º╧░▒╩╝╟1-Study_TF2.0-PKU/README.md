# Tensorflow2.0学习笔记

该学习笔记整理自mooc网课程——人工智能实践：Tensorflow笔记

mooc链接：https://www.icourse163.org/course/PKU-1002536002

B站视频链接：https://www.bilibili.com/video/BV1B7411L7Qt

源码下载链接：https://pan.baidu.com/s/19XC28Hz_TwnSQeuVifg1UQ 提取码：mocm

​		该课程由北京大学，软件与微电子学院，曹健老师出品，非常详实的介绍了Tensorflow2.0的使用教程，从tf2.0安装、常用API、卷积、循环层等，入门tf2.0较好的教程。
