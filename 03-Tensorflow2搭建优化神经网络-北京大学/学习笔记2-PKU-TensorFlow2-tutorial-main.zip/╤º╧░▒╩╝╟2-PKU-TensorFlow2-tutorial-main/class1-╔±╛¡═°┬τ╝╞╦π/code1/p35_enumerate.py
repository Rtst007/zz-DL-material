seq = ['one', 'two', 'three']
for i, element in enumerate(seq):
    print(i, element)
