# README.md

本教程来源于北京大学软件与微电子学院曹健老师的课程《人工智能实践：TensorFlow2笔记》



课程中用到的MNIST和FASHION数据集下载链接如下：

链接：https://pan.baidu.com/s/1QxRNFl5p2bEDWKyCKb9gQw?pwd=xonb 
提取码：xonb 
--来自百度网盘超级会员V6的分享



课程笔记：

https://blog.csdn.net/qq_43629945/category_11888831.html
